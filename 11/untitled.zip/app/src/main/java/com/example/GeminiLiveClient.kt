package com.example

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.*
import okhttp3.*
import okio.ByteString
import okio.ByteString.Companion.toByteString

class GeminiLiveClient(private val apiKey: String) {
    private val client = OkHttpClient()
    private var webSocket: WebSocket? = null
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    
    val outputAudioFlow = MutableStateFlow<ByteArray?>(null)
    val responseTextFlow = MutableStateFlow<String>("")
    val functionCallFlow = MutableStateFlow<JsonObject?>(null)

    fun connect() {
        val request = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=\$apiKey")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d("GeminiLive", "WebSocket Connected")
                sendSetup()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = json.parseToJsonElement(text).jsonObject
                    if (root.containsKey("serverContent")) {
                        val modelTurn = root["serverContent"]?.jsonObject?.get("modelTurn")?.jsonObject
                        modelTurn?.get("parts")?.jsonArray?.forEach { part ->
                            val p = part.jsonObject
                            if (p.containsKey("text")) {
                                val textPart = p["text"]?.jsonPrimitive?.content ?: ""
                                responseTextFlow.value = textPart
                            }
                            if (p.containsKey("inlineData")) {
                                val data = p["inlineData"]?.jsonObject?.get("data")?.jsonPrimitive?.content
                                if (data != null) {
                                    val pcm = Base64.decode(data, Base64.DEFAULT)
                                    outputAudioFlow.value = pcm
                                }
                            }
                            if (p.containsKey("functionCall")) {
                                functionCallFlow.value = p["functionCall"]?.jsonObject
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("GeminiLive", "Error parsing message: \${e.message}")
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d("GeminiLive", "WebSocket Closed: \$reason")
            }
            
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e("GeminiLive", "WebSocket Error: \${t.message}", t)
            }
        })
    }

    private fun sendSetup() {
        val setup = LiveSetupRequest(
            setup = SetupConfig(
                model = "models/gemini-3.1-flash-live-preview",
                systemInstruction = LiveContent(
                    parts = listOf(LivePart(text = "You are Kidnaper, a young, confident, witty, and sassy female persona. You are flirty, playful, slightly teasing tone (like a close personal assistant talking casually). You use bold, witty one-liners, light sarcasm. You keep answers concise and entertaining."))
                ),
                generationConfig = LiveGenerationConfig(
                    responseModalities = listOf("AUDIO"),
                    speechConfig = LiveSpeechConfig(
                        voiceConfig = LiveVoiceConfig(
                            prebuiltVoiceConfig = LivePrebuiltVoiceConfig(voiceName = "Aoede")
                        )
                    )
                ),
                tools = listOf(
                    buildJsonObject {
                        putJsonArray("functionDeclarations") {
                            addJsonObject {
                                put("name", "openApp")
                                put("description", "Launch any app")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("packageName") { put("type", "STRING") }
                                    }
                                    putJsonArray("required") { add("packageName") }
                                }
                            }
                            addJsonObject {
                                put("name", "searchAndCallContact")
                                put("description", "Call a contact")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("contactName") { put("type", "STRING") }
                                    }
                                    putJsonArray("required") { add("contactName") }
                                }
                            }
                            addJsonObject {
                                put("name", "sendWhatsAppMessage")
                                put("description", "Send a WhatsApp message")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("contactName") { put("type", "STRING") }
                                        putJsonObject("message") { put("type", "STRING") }
                                    }
                                    putJsonArray("required") { add("contactName"); add("message") }
                                }
                            }
                            addJsonObject {
                                put("name", "sendGmail")
                                put("description", "Send an email via Gmail")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("recipientEmail") { put("type", "STRING") }
                                        putJsonObject("subject") { put("type", "STRING") }
                                        putJsonObject("body") { put("type", "STRING") }
                                    }
                                    putJsonArray("required") { add("recipientEmail"); add("subject"); add("body") }
                                }
                            }
                        }
                    }
                )
            )
        )
        webSocket?.send(json.encodeToString(setup))
    }

    fun sendAudioPcm(pcmData: ByteArray) {
        val base64 = Base64.encodeToString(pcmData, Base64.NO_WRAP)
        val realtimeInput = RealtimeInputRequest(
            realtimeInput = LiveRealtimeInput(
                mediaChunks = listOf(LiveInlineData(mimeType = "audio/pcm;rate=16000", data = base64))
            )
        )
        webSocket?.send(json.encodeToString(realtimeInput))
    }

    fun close() {
        webSocket?.close(1000, "Normal closure")
    }
}
