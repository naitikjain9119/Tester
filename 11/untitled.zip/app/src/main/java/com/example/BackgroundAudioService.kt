package com.example

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.math.sqrt

class BackgroundAudioService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isRecording = false
    private lateinit var liveClient: GeminiLiveClient
    
    companion object {
        private const val CHANNEL_ID = "kidnaper_channel"
        private const val SAMPLE_RATE = 16000
        private const val PLAYBACK_RATE = 24000
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, buildNotification())
        }
        
        liveClient = GeminiLiveClient(BuildConfig.GEMINI_API_KEY)
        liveClient.connect()
        
        KidnaperStateManager.updateState { it.copy(isActive = true, statusText = "CONNECTED") }
        startAudioProcessing()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startAudioProcessing() {
        val bufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        val trackBufferSize = AudioTrack.getMinBufferSize(
            PLAYBACK_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        audioTrack = AudioTrack(
            AudioManager.STREAM_MUSIC,
            PLAYBACK_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            trackBufferSize,
            AudioTrack.MODE_STREAM
        )
        audioTrack?.play()

        isRecording = true
        audioRecord?.startRecording()

        // Read mic and send to Gemini
        scope.launch {
            val buffer = ShortArray(bufferSize / 2)
            val byteBuffer = ByteArray(bufferSize)
            while (isRecording && isActive) {
                val readSize = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (readSize > 0) {
                    var sum = 0.0
                    for (i in 0 until readSize) {
                        sum += buffer[i] * buffer[i]
                        byteBuffer[i * 2] = (buffer[i].toInt() and 0x00FF).toByte()
                        byteBuffer[i * 2 + 1] = (buffer[i].toInt() shr 8).toByte()
                    }
                    val rms = sqrt(sum / readSize)
                    if (rms > 200 && !KidnaperStateManager.stateFlow.value.isMuted) { // basic noise gate
                        KidnaperStateManager.updateState { it.copy(isListening = true, statusText = "LISTENING") }
                        liveClient.sendAudioPcm(byteBuffer.copyOfRange(0, readSize * 2))
                        // Interrupt playing if user speaks loud
                        audioTrack?.pause()
                        audioTrack?.flush()
                        audioTrack?.play()
                    } else {
                        KidnaperStateManager.updateState { it.copy(isListening = false, statusText = if (it.isThinking) "THINKING" else "IDLE") }
                    }
                }
            }
        }

        // Receive audio from Gemini and play
        scope.launch {
            liveClient.outputAudioFlow.collectLatest { pcm ->
                if (pcm != null && pcm.isNotEmpty()) {
                    audioTrack?.write(pcm, 0, pcm.size)
                }
            }
        }
        
        scope.launch {
            liveClient.responseTextFlow.collectLatest { text ->
                if (text.isNotEmpty()) {
                    KidnaperStateManager.updateState { it.copy(latestMessage = text, isThinking = true) }
                    delay(3000)
                    KidnaperStateManager.updateState { it.copy(isThinking = false) }
                }
            }
        }

        // Function Calls
        val toolEngine = ToolExecutionEngine(this@BackgroundAudioService)
        scope.launch {
            liveClient.functionCallFlow.collectLatest { call ->
                call?.let {
                    val name = it["name"]?.jsonPrimitive?.content
                    val argsJson = it["args"]?.jsonObject
                    if (name != null && argsJson != null) {
                        val argsMap = mutableMapOf<String, String>()
                        argsJson.forEach { (key, value) ->
                            argsMap[key] = value.jsonPrimitive.content
                        }
                        toolEngine.execute(name, argsMap)
                    }
                }
            }
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Kidnaper Active")
            .setContentText("Listening for commands...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kidnaper Background Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        KidnaperStateManager.updateState { it.copy(isActive = false, statusText = "DISCONNECTED") }
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
        audioTrack?.stop()
        audioTrack?.release()
        liveClient.close()
        scope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
