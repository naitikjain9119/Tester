package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.Pink500
import com.example.ui.theme.Slate100
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val permissions = rememberMultiplePermissionsState(
                    permissions = listOfNotNull(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.CALL_PHONE,
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            Manifest.permission.POST_NOTIFICATIONS
                        } else null
                    )
                )

                if (permissions.allPermissionsGranted) {
                    val state by KidnaperStateManager.stateFlow.collectAsState()
                    KidnaperScreen(
                        state = state,
                        onMuteClick = { KidnaperStateManager.updateState { it.copy(isMuted = !it.isMuted) } },
                        onEndClick = {
                            stopService(Intent(this@MainActivity, BackgroundAudioService::class.java))
                            finish()
                        }
                    )
                    
                    // Start service if not running
                    LaunchedEffect(Unit) {
                        val serviceIntent = Intent(this@MainActivity, BackgroundAudioService::class.java)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(serviceIntent)
                        } else {
                            startService(serviceIntent)
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(BackgroundDark)
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text("Welcome to Kidnaper", style = MaterialTheme.typography.headlineMedium, color = Slate100)
                            Text("I need some permissions to take over... I mean, help you out.", color = Slate100)
                            Button(
                                onClick = { permissions.launchMultiplePermissionRequest() },
                                colors = ButtonDefaults.buttonColors(containerColor = Pink500)
                            ) {
                                Text("Grant Permissions", color = Slate100)
                            }
                        }
                    }
                }
            }
        }
    }
}

