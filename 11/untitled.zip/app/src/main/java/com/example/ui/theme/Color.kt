package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Vibrant Palette Colors
val BackgroundDark = Color(0xFF0A0A10)
val Pink500 = Color(0xFFEC4899)
val Indigo600 = Color(0xFF4F46E5)
val Purple800 = Color(0xFF6B21A8)
val Slate100 = Color(0xFFF1F5F9)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Teal500 = Color(0xFF14B8A6)
val Orange500 = Color(0xFFF97316)
val Red500 = Color(0xFFEF4444)
val Green500 = Color(0xFF22C55E)

