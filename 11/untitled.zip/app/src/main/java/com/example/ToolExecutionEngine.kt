package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log

class ToolExecutionEngine(private val context: Context) {
    fun execute(name: String, args: Map<String, String>) {
        try {
            when (name) {
                "openApp" -> {
                    val packageName = args["packageName"]
                    if (packageName != null) {
                        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
                        if (launchIntent != null) {
                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(launchIntent)
                        } else {
                            Log.e("ToolExecution", "App not found: \$packageName")
                        }
                    }
                }
                "searchAndCallContact" -> {
                    val contactName = args["contactName"]
                    if (contactName != null) {
                        val phoneNumber = getPhoneNumber(contactName)
                        if (phoneNumber != null) {
                            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:\$phoneNumber"))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        }
                    }
                }
                "sendWhatsAppMessage" -> {
                    val contactName = args["contactName"]
                    val message = args["message"] ?: ""
                    if (contactName != null) {
                        val phoneNumber = getPhoneNumber(contactName)
                        if (phoneNumber != null) {
                            // clean up number
                            val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
                            val url = "https://api.whatsapp.com/send?phone=\$cleanNumber&text=${Uri.encode(message)}"
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            intent.setPackage("com.whatsapp")
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        }
                    }
                }
                "sendGmail" -> {
                    val recipientEmail = args["recipientEmail"] ?: ""
                    val subject = args["subject"] ?: ""
                    val body = args["body"] ?: ""
                    
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:\$recipientEmail")
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, body)
                        setPackage("com.google.android.gm")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            }
        } catch (e: Exception) {
            Log.e("ToolExecution", "Error executing \$name: \${e.message}")
        }
    }
    
    private fun getPhoneNumber(name: String): String? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val selection = "\${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%\$name%")
        
        context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (numIdx >= 0) return cursor.getString(numIdx)
            }
        }
        return null
    }
}
