package com.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

@Serializable
data class LiveSetupRequest(
    val setup: SetupConfig
)

@Serializable
data class SetupConfig(
    val model: String = "models/gemini-3.1-flash-live-preview",
    val generationConfig: LiveGenerationConfig? = null,
    val systemInstruction: LiveContent? = null,
    val tools: List<JsonObject>? = null
)

@Serializable
data class LiveGenerationConfig(
    val responseModalities: List<String> = listOf("AUDIO", "TEXT"),
    val speechConfig: LiveSpeechConfig? = null
)

@Serializable
data class LiveSpeechConfig(
    val voiceConfig: LiveVoiceConfig
)

@Serializable
data class LiveVoiceConfig(
    val prebuiltVoiceConfig: LivePrebuiltVoiceConfig
)

@Serializable
data class LivePrebuiltVoiceConfig(
    val voiceName: String
)

@Serializable
data class LiveContent(
    val parts: List<LivePart>,
    val role: String = "user"
)

@Serializable
data class LivePart(
    val text: String? = null,
    val inlineData: LiveInlineData? = null
)

@Serializable
data class LiveInlineData(
    val mimeType: String,
    val data: String
)

@Serializable
data class ClientContentRequest(
    val clientContent: LiveClientContent
)

@Serializable
data class LiveClientContent(
    val turns: List<LiveContent>,
    val turnComplete: Boolean
)

@Serializable
data class RealtimeInputRequest(
    val realtimeInput: LiveRealtimeInput
)

@Serializable
data class LiveRealtimeInput(
    val mediaChunks: List<LiveInlineData>
)
