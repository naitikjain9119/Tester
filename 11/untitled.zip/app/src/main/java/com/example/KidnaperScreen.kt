package com.example

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Message
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun KidnaperScreen(
    state: KidnaperState,
    onMuteClick: () -> Unit,
    onEndClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(colors = listOf(Pink500, Indigo600), start = Offset(0f, Float.POSITIVE_INFINITY), end = Offset(Float.POSITIVE_INFINITY, 0f))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("K", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                    Column {
                        Text("Kidnaper", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Slate100)
                        Text(
                            text = if (state.isActive) "Gemini Live Active" else "Disconnected",
                            fontSize = 12.sp,
                            color = Pink500,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Slate800.copy(alpha = 0.5f))
                        .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                        .clickable { /* settings */ },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Slate300, modifier = Modifier.size(20.dp))
                }
            }
            
            // Main Content: Sassy Assistant Core
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                // Atmosphere Glow
                Box(
                    modifier = Modifier
                        .size(256.dp)
                        .blur(100.dp)
                        .background(Pink500.copy(alpha = 0.2f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .offset(x = 48.dp, y = 48.dp)
                        .size(192.dp)
                        .blur(100.dp)
                        .background(Indigo600.copy(alpha = 0.2f), CircleShape)
                )
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(32.dp)
                ) {
                    KidnaperOrb(state = state)
                    
                    // Conversation UI
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(24.dp, 24.dp, 24.dp, 0.dp),
                            color = Slate800.copy(alpha = 0.8f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                            shadowElevation = 12.dp
                        ) {
                            Text(
                                text = state.latestMessage.ifEmpty { "Waiting for your command..." },
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                                color = Color(0xFFE0E7FF), // indigo-100
                                fontSize = 18.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                        Text(
                            text = state.statusText.uppercase(),
                            color = Slate500,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
            
            // Bottom Tool Tray
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(32.dp),
                color = Slate900.copy(alpha = 0.6f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("QUICK COMMANDS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Slate400, letterSpacing = 1.sp)
                        Surface(
                            shape = CircleShape,
                            color = Indigo600.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Indigo600.copy(alpha = 0.3f))
                        ) {
                            Text("Tools Enabled", fontSize = 10.sp, color = Color(0xFFA5B4FC), modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                        }
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ToolIcon(icon = Icons.Rounded.Call, label = "Call", color = Indigo600)
                        ToolIcon(icon = Icons.Rounded.Message, label = "Text", color = Pink500)
                        ToolIcon(icon = Icons.Rounded.Apps, label = "Apps", color = Teal500)
                        ToolIcon(icon = Icons.Rounded.Email, label = "Mail", color = Orange500)
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Slate800)
                                    .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                                    .clickable { onMuteClick() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(if (state.isMuted) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = "Mute", tint = Slate100, modifier = Modifier.size(24.dp))
                            }
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Red500.copy(alpha = 0.2f))
                                    .border(1.dp, Red500.copy(alpha = 0.4f), CircleShape)
                                    .clickable { onEndClick() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "End", tint = Red500, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KidnaperOrb(state: KidnaperState) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (state.isThinking) 1.15f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (state.isThinking) 800 else 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(contentAlignment = Alignment.Center) {
        // Ring 1
        Box(
            modifier = Modifier
                .size(256.dp)
                .scale(pulseScale)
                .border(1.dp, Pink500.copy(alpha = 0.2f), CircleShape)
        )
        // Ring 2
        Box(
            modifier = Modifier
                .size(208.dp)
                .border(2.dp, Indigo600.copy(alpha = 0.3f), CircleShape)
        )
        // Main Orb
        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(colors = listOf(Pink500, Indigo600, Purple800), start = Offset(0f, 0f), end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)))
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(BackgroundDark.copy(alpha = 0.4f))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.GraphicEq,
                    contentDescription = "Audio Wave",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }
    }
}

@Composable
fun ToolIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(color.copy(alpha = 0.1f))
                .border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = color.copy(alpha = 0.8f), modifier = Modifier.size(24.dp))
        }
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
    }
}

data class KidnaperState(
    val isActive: Boolean = false,
    val isListening: Boolean = false,
    val isThinking: Boolean = false,
    val isSpeaking: Boolean = false,
    val isMuted: Boolean = false,
    val latestMessage: String = "",
    val statusText: String = "IDLE"
)
