package com.example

import kotlinx.coroutines.flow.MutableStateFlow

object KidnaperStateManager {
    val stateFlow = MutableStateFlow(KidnaperState(statusText = "IDLE"))
    
    fun updateState(reducer: (KidnaperState) -> KidnaperState) {
        stateFlow.value = reducer(stateFlow.value)
    }
}
